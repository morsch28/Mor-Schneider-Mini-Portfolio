
function add(){
    let box = document.createElement("DIV");
    box.style.width = "100px";
    box.style.height = "100px";
    box.style.border = "1px solid black";
    document.getElementById("inbox").appendChild(box);
    
}